import json
import os
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import boto3
from datetime import datetime

def lambda_handler(event, context):
    client_id     = os.environ.get("client_id")
    client_secret = os.environ.get("client_secret")
    playlist_id   = "3cEYpjA9oz9GiPac4AsH4n"

    sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
        client_id=client_id,
        client_secret=client_secret
    ))

    spotify_data = sp.playlist(playlist_id)
    

    client = boto3.client('s3')

    filename = 'spotify_raw_' + str(datetime.now().strftime('%Y-%m-%d_%H-%M-%S'))+ ".json"

    client.put_object(
        Bucket='spotify-etl-project-sabareesh',
        Key='raw_data/to_process/' + filename,
        Body= json.dumps(spotify_data)
    )